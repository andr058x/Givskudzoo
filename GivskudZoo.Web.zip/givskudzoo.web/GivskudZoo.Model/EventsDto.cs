﻿using System;

namespace GivskudZoo.Model
{
    public class EventsDto
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string ShortDescription { get; set; }
        public string Description { get; set; }
        public string Author { get; set; }
        public int? ImageId { get; set; }
        public bool DeleteImage { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime LastUpdateDate { get; set; }

        public ImageDto Image { get; set; }
    }
}