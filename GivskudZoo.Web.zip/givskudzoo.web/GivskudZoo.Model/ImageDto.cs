﻿using System;
using Newtonsoft.Json;

namespace GivskudZoo.Model
{
    public class ImageDto
    {
        public int Id { get; set; }
        public string FileName { get; set; }
        public string MimeType { get; set; }
        [JsonIgnore]
        public byte[] Blob { get; set; }
        public int Size { get; set; }

        public string ImageUrl => $"data:image/png;base64,{Convert.ToBase64String(Blob)}";
    }
}